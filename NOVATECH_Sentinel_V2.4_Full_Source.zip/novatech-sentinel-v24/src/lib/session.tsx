import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, rpc, RpcError, isSupabaseConfigured } from './supabase';
import { demoPersonas, getDemoPersona, setDemoPersona, subscribeDemo, type DemoPersona } from '../enterprise/demo/demoSession.ts';

export type Membership = {
  org_id: string; org_name: string; industry: string; kind: 'primary' | 'template'; currency: string;
  employee_id: string; full_name: string; role_id: string; role: string; authority_level: number;
  department: string; is_student: boolean; permissions: string[];
  delegated_roles: { role: string; from: string; until: string }[];
};
export type { DemoPersona };

type Ctx = {
  session: Session | null;
  loading: boolean;
  memberships: Membership[];
  current: Membership | null;
  orgId: string;
  setOrg: (id: string) => void;
  can: (perm: string) => boolean;
  refreshKey: number;
  bump: () => void;
  signOut: () => Promise<void>;
  reloadSession: () => Promise<void>;
  /** True in the public demo (no Supabase configuration): data comes from the simulated backend. */
  demo: boolean;
  /** Public demo: the person the visitor acts as (null in the authenticated workspace). */
  persona: DemoPersona | null;
  /** Public demo: everyone the visitor can act as (empty in the authenticated workspace). */
  personas: DemoPersona[];
  /** Public demo: act as another person (no-op in the authenticated workspace). */
  setPersona: (employeeId: string) => void;
};

const SessionCtx = createContext<Ctx | null>(null);

function safeGet(k: string) { try { return localStorage.getItem(k); } catch { return null; } }
function safeSet(k: string, v: string) { try { localStorage.setItem(k, v); } catch { /* ignore */ } }

/** The public demo runs when the build has no Supabase settings. */
const DEMO_MODE = !isSupabaseConfigured();
const DEMO_ORG = 'NT';
const noPersona = () => undefined;

export function SessionProvider({ children }: { children: ReactNode }) {
  return DEMO_MODE ? <DemoSessionProvider>{children}</DemoSessionProvider> : <SupabaseSessionProvider>{children}</SupabaseSessionProvider>;
}

function SupabaseSessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [orgId, setOrgId] = useState<string>(safeGet('grc-org') ?? 'NT');
  const [refreshKey, setRefreshKey] = useState(0);

  const reloadSession = useCallback(async () => {
    try {
      const s = await rpc<{ memberships: Membership[] }>('grc_session');
      setMemberships(s.memberships ?? []);
    } catch {
      setMemberships([]);
    }
  }, []);

  useEffect(() => {
    let live = true;
    // Never await Supabase calls inside onAuthStateChange: it holds the auth lock and deadlocks.
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      if (!live) return;
      setSession(s);
      setTimeout(async () => {
        if (s) await reloadSession(); else setMemberships([]);
        if (live) setLoading(false);
      }, 0);
    });
    // Safety net: never leave the user on a spinner.
    const t = setTimeout(() => live && setLoading(false), 8000);
    return () => { live = false; clearTimeout(t); sub.subscription.unsubscribe(); };
  }, [reloadSession]);

  const current = useMemo(
    () => memberships.find(m => m.org_id === orgId) ?? memberships[0] ?? null,
    [memberships, orgId]);

  const setOrg = useCallback((id: string) => { setOrgId(id); safeSet('grc-org', id); setRefreshKey(k => k + 1); }, []);
  const can = useCallback((p: string) => !!current?.permissions.includes(p), [current]);
  const bump = useCallback(() => setRefreshKey(k => k + 1), []);
  const signOut = useCallback(async () => { await supabase.auth.signOut(); setMemberships([]); }, []);

  return (
    <SessionCtx.Provider value={{
      session, loading, memberships, current, orgId: current?.org_id ?? orgId, setOrg, can, refreshKey, bump, signOut, reloadSession,
      demo: false, persona: null, personas: [], setPersona: noPersona,
    }}>
      {children}
    </SessionCtx.Provider>
  );
}

/** A stand-in for the Supabase session in the public demo (it carries no token). */
function demoSessionFor(p: DemoPersona): Session {
  return {
    access_token: '', refresh_token: '', token_type: 'bearer', expires_in: 0,
    user: {
      id: p.employee_id, aud: 'public-demo', role: 'public-demo', email: p.email ?? undefined, created_at: '2026-10-25T10:00:15.371711+00:00',
      app_metadata: { provider: 'public-demo' }, user_metadata: { full_name: p.full_name, public_demo: true },
    },
  } as Session;
}

function DemoSessionProvider({ children }: { children: ReactNode }) {
  const [persona, setPersonaState] = useState<DemoPersona>(() => getDemoPersona());
  const [personas, setPersonas] = useState<DemoPersona[]>(() => demoPersonas());
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  const reloadSession = useCallback(async () => {
    try {
      const s = await rpc<{ memberships: Membership[] }>('grc_session');
      setMemberships((s.memberships ?? []).filter(m => m.org_id === DEMO_ORG));
    } catch {
      setMemberships([]);
    }
    setPersonas(demoPersonas());
    setPersonaState(getDemoPersona());
  }, []);

  useEffect(() => {
    let live = true;
    reloadSession().finally(() => { if (live) setLoading(false); });
    // Persona switches, simulated writes and resets refresh the session and every useRpc.
    const off = subscribeDemo(event => {
      if (!live) return;
      if (event.type === 'data') { setRefreshKey(k => k + 1); void reloadSession(); return; }
      void reloadSession().then(() => { if (live) setRefreshKey(k => k + 1); });
    });
    return () => { live = false; off(); };
  }, [reloadSession]);

  const session = useMemo(() => demoSessionFor(persona), [persona]);
  const current = useMemo(() => memberships.find(m => m.org_id === DEMO_ORG) ?? memberships[0] ?? null, [memberships]);
  const setOrg = useCallback(() => { /* the public demo has one organisation (NT) */ }, []);
  const can = useCallback((p: string) => !!current?.permissions.includes(p), [current]);
  const bump = useCallback(() => setRefreshKey(k => k + 1), []);
  const signOut = useCallback(async () => { window.location.assign('/'); }, []);
  const setPersona = useCallback((employeeId: string) => { setDemoPersona(employeeId); }, []);

  return (
    <SessionCtx.Provider value={{
      session, loading, memberships, current, orgId: current?.org_id ?? DEMO_ORG, setOrg, can, refreshKey, bump, signOut, reloadSession,
      demo: true, persona, personas, setPersona,
    }}>
      {children}
    </SessionCtx.Provider>
  );
}

export const useSession = () => {
  const c = useContext(SessionCtx);
  if (!c) throw new Error('SessionProvider missing');
  return c;
};

/** Load data from an RPC; reloads when the global refresh key changes and on a gentle interval. */
export function useRpc<T>(fn: string | null, args: Record<string, unknown> = {}, opts: { poll?: number } = {}) {
  const { refreshKey } = useSession();
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<RpcError | null>(null);
  const [loading, setLoading] = useState(true);
  const argKey = JSON.stringify(args);
  const mounted = useRef(true);

  const load = useCallback(async (quiet = false) => {
    if (!fn) return;
    if (!quiet) setLoading(true);
    try {
      const d = await rpc<T>(fn, JSON.parse(argKey));
      if (mounted.current) { setData(d); setError(null); }
    } catch (e) {
      if (mounted.current) setError(e as RpcError);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [fn, argKey]);

  useEffect(() => { mounted.current = true; load(); return () => { mounted.current = false; }; }, [load, refreshKey]);
  useEffect(() => {
    if (!opts.poll) return;
    const t = setInterval(() => { if (document.visibilityState === 'visible') load(true); }, opts.poll);
    return () => clearInterval(t);
  }, [load, opts.poll]);

  return { data, error, loading, reload: () => load(true) };
}
